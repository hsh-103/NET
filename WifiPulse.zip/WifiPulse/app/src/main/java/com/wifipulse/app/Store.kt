package com.wifipulse.app

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Store {
    private lateinit var sp: SharedPreferences

    fun init(c: Context) {
        if (!::sp.isInitialized) sp = c.applicationContext.getSharedPreferences("wp", Context.MODE_PRIVATE)
    }

    fun dayKey(t: Long = System.currentTimeMillis()): String =
        SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(t))

    fun networks(): Set<String> = HashSet(sp.getStringSet("nets", emptySet()) ?: emptySet())

    fun touch(ssid: String) {
        val s = networks().toMutableSet(); s.add(ssid)
        sp.edit().putStringSet("nets", s).putLong("last|$ssid", System.currentTimeMillis()).apply()
    }

    fun lastActive(ssid: String): Long = sp.getLong("last|$ssid", 0L)

    fun add(ssid: String, bytes: Long) {
        val k = "u|$ssid|${dayKey()}"
        sp.edit().putLong(k, sp.getLong(k, 0L) + bytes).putLong("lw", System.currentTimeMillis()).apply()
    }

    /** prefix: "" = total, "yyyyMM" = month, "yyyyMMdd" = day */
    fun usage(ssid: String, prefix: String): Long {
        val start = "u|$ssid|$prefix"
        var sum = 0L
        for ((k, v) in sp.all) if (k.startsWith(start) && v is Long) sum += v
        return sum
    }

    fun capDay(ssid: String): Long = sp.getLong("cd|$ssid", 0L)
    fun capMonth(ssid: String): Long = sp.getLong("cm|$ssid", 0L)
    fun setCaps(ssid: String, dayMb: Long, monthMb: Long) {
        sp.edit().putLong("cd|$ssid", dayMb).putLong("cm|$ssid", monthMb).apply()
    }

    fun blockOn(ssid: String): Boolean = sp.getBoolean("bo|$ssid", false)
    fun setBlockOn(ssid: String, v: Boolean) { sp.edit().putBoolean("bo|$ssid", v).apply() }

    fun snoozed(ssid: String): Boolean = sp.getString("sz|$ssid", "") == dayKey()
    fun setSnooze(ssid: String, day: String = dayKey()) { sp.edit().putString("sz|$ssid", day).apply() }

    fun blockedApps(): Set<String> = HashSet(sp.getStringSet("apps", emptySet()) ?: emptySet())
    fun setBlockedApps(s: Set<String>) { sp.edit().putStringSet("apps", s).apply() }

    fun delete(ssid: String) {
        val e = sp.edit()
        for (k in sp.all.keys) if (k.startsWith("u|$ssid|") || k.endsWith("|$ssid")) e.remove(k)
        val s = networks().toMutableSet(); s.remove(ssid)
        e.putStringSet("nets", s).apply()
    }

    var currentSsid: String
        get() = sp.getString("cur", "") ?: ""
        set(v) { sp.edit().putString("cur", v).apply() }
    var lastDelta: Long
        get() = sp.getLong("ld", 0L)
        set(v) { sp.edit().putLong("ld", v).apply() }
    val lastWrite: Long get() = sp.getLong("lw", 0L)
    var blocking: Boolean
        get() = sp.getBoolean("blk", false)
        set(v) { sp.edit().putBoolean("blk", v).apply() }
    var running: Boolean
        get() = sp.getBoolean("run", false)
        set(v) { sp.edit().putBoolean("run", v).apply() }
}

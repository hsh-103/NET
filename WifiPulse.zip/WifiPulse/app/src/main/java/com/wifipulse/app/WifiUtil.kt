package com.wifipulse.app

import android.content.Context
import android.net.TrafficStats
import android.net.wifi.WifiManager

object WifiUtil {
    /** Name of the connected Wi-Fi network, or null if not connected. */
    fun currentWifi(ctx: Context): String? {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        if (!wm.isWifiEnabled) return null
        @Suppress("DEPRECATION")
        val info = wm.connectionInfo ?: return null
        if (info.networkId == -1) return null
        var s = info.ssid?.removeSurrounding("\"") ?: ""
        if (s.isBlank() || s == "<unknown ssid>") {
            val b = info.bssid
            s = if (b != null && b != "02:00:00:00:00:00") b else "Wi-Fi (unknown)"
        }
        return s
    }

    /** Total bytes (rx+tx) that went through non-mobile interfaces since boot. */
    fun wifiBytes(): Long {
        val total = TrafficStats.getTotalRxBytes() + TrafficStats.getTotalTxBytes()
        val mobile = TrafficStats.getMobileRxBytes() + TrafficStats.getMobileTxBytes()
        return (total - mobile).coerceAtLeast(0L)
    }
}

package com.wifipulse.app

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor

/**
 * Local firewall: apps routed into this VPN get no packets read, so their traffic is dropped.
 * No remote server involved.
 */
class FirewallVpnService : VpnService() {
    private var pfd: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Store.init(this)
        pfd?.close(); pfd = null
        try {
            val b = Builder()
                .setSession("WiFi Pulse Firewall")
                .addAddress("10.255.0.1", 32)
                .addAddress("fd00:1::1", 128)
                .addRoute("0.0.0.0", 0)
                .addRoute("::", 0)
            val apps = Store.blockedApps()
            if (apps.isEmpty()) {
                b.addDisallowedApplication(packageName) // block everything except this app
            } else {
                for (a in apps) try { b.addAllowedApplication(a) } catch (_: Exception) {}
            }
            pfd = b.establish()
            Store.blocking = pfd != null
        } catch (e: Exception) {
            Store.blocking = false
            stopSelf()
        }
        return START_STICKY
    }

    override fun onRevoke() { Store.blocking = false; stopSelf() }

    override fun onDestroy() {
        pfd?.close(); pfd = null
        Store.blocking = false
        super.onDestroy()
    }
}

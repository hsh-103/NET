package com.wifipulse.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(color = MaterialTheme.colorScheme.background) { App() }
            }
        }
    }
}

fun fmt(b: Long): String =
    if (b >= 1024L * 1024 * 1024) String.format(Locale.US, "%.2f GB", b / 1073741824.0)
    else String.format(Locale.US, "%.1f MB", b / 1048576.0)

fun fmtTime(t: Long): String =
    if (t == 0L) "—" else SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(t))

@Composable
fun rememberTick(): Int {
    var t by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(3000); t++ } }
    return t
}

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    val titles = listOf("الشبكات", "التطبيقات", "الحالة")
    Scaffold(bottomBar = {
        NavigationBar {
            titles.forEachIndexed { i, t ->
                NavigationBarItem(
                    selected = tab == i, onClick = { tab = i },
                    icon = {
                        Icon(
                            when (i) { 0 -> Icons.Default.Home; 1 -> Icons.Default.Menu; else -> Icons.Default.Info },
                            contentDescription = null
                        )
                    },
                    label = { Text(t) }
                )
            }
        }
    }) { p ->
        Box(Modifier.padding(p)) {
            when (tab) { 0 -> NetworksScreen(); 1 -> AppsScreen(); else -> StatusScreen() }
        }
    }
}

@Composable
fun NetworksScreen() {
    val tick = rememberTick()
    var ver by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<String?>(null) }
    val nets = remember(tick, ver) { Store.networks().sortedByDescending { Store.lastActive(it) } }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("الشبكات المراقبة", style = MaterialTheme.typography.headlineMedium) }
        if (nets.isEmpty()) item { Text("لا توجد شبكات بعد. افتح تبويب (الحالة)، امنح الأذونات وشغّل المراقبة.") }
        items(nets, key = { it }) { ssid ->
            NetCard(ssid, tick, onLimits = { editing = ssid }, onDelete = { Store.delete(ssid); ver++ })
        }
    }
    editing?.let { LimitsDialog(it) { editing = null; ver++ } }
}

@Composable
fun NetCard(ssid: String, tick: Int, onLimits: () -> Unit, onDelete: () -> Unit) {
    val mb = 1024L * 1024L
    val day = Store.dayKey()
    val (today, month, total) = remember(tick, ssid) {
        Triple(Store.usage(ssid, day), Store.usage(ssid, day.substring(0, 6)), Store.usage(ssid, ""))
    }
    val cd = Store.capDay(ssid); val cm = Store.capMonth(ssid)
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(ssid, style = MaterialTheme.typography.titleLarge)
                    Text("آخر نشاط: ${fmtTime(Store.lastActive(ssid))}", style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "حذف") }
            }
            Text("اليوم: ${fmt(today)}")
            if (cd > 0) LinearProgressIndicator(progress = { (today.toFloat() / (cd * mb)).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
            if (cd > 0) Text("الحد اليومي: $cd MB", style = MaterialTheme.typography.bodySmall)
            Text("هذا الشهر: ${fmt(month)}")
            if (cm > 0) LinearProgressIndicator(progress = { (month.toFloat() / (cm * mb)).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
            if (cm > 0) Text("الحد الشهري: $cm MB", style = MaterialTheme.typography.bodySmall)
            Text("الإجمالي: ${fmt(total)}")
            if (Store.blockOn(ssid)) Text("الحظر عند بلوغ الحد: مفعّل", style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = onLimits) { Text("الحدود والحظر") }
        }
    }
}

@Composable
fun LimitsDialog(ssid: String, onClose: () -> Unit) {
    var d by remember { mutableStateOf(Store.capDay(ssid).let { if (it > 0) it.toString() else "" }) }
    var m by remember { mutableStateOf(Store.capMonth(ssid).let { if (it > 0) it.toString() else "" }) }
    var b by remember { mutableStateOf(Store.blockOn(ssid)) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(ssid) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = d, onValueChange = { d = it.filter(Char::isDigit) },
                    label = { Text("الحد اليومي (MB) — فارغ = بدون") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                OutlinedTextField(
                    value = m, onValueChange = { m = it.filter(Char::isDigit) },
                    label = { Text("الحد الشهري (MB) — فارغ = بدون") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = b, onCheckedChange = { b = it })
                    Spacer(Modifier.width(8.dp))
                    Text("حظر التطبيقات عند بلوغ الحد")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                Store.setCaps(ssid, d.toLongOrNull() ?: 0L, m.toLongOrNull() ?: 0L)
                Store.setBlockOn(ssid, b)
                Store.setSnooze(ssid, "")
                onClose()
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("إلغاء") } }
    )
}

@Composable
fun AppsScreen() {
    val ctx = LocalContext.current
    val apps by produceState<List<Pair<String, String>>>(emptyList()) {
        value = withContext(Dispatchers.Default) {
            val pm = ctx.packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(i, 0)
                .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
                .filter { it.first != ctx.packageName }
                .distinctBy { it.first }
                .sortedBy { it.second.lowercase() }
        }
    }
    var sel by remember { mutableStateOf(Store.blockedApps()) }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        item {
            Text("التطبيقات المراد حظرها", style = MaterialTheme.typography.headlineMedium)
            Text(
                "عند بلوغ الحد (للشبكات المفعّل فيها الحظر) تُحظر التطبيقات المختارة. " +
                    "إذا لم تختر أي تطبيق، يُحظر كل شيء ما عدا هذا التطبيق.",
                style = MaterialTheme.typography.bodySmall
            )
        }
        items(apps, key = { it.first }) { (pkg, name) ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = pkg in sel, onCheckedChange = {
                    sel = if (pkg in sel) sel - pkg else sel + pkg
                    Store.setBlockedApps(sel)
                })
                Column {
                    Text(name)
                    Text(pkg, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun StatusScreen() {
    val ctx = LocalContext.current
    val tick = rememberTick()
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    val vpnLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { }

    val loc = remember(tick) {
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }
    val locOn = remember(tick) {
        (ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager).isLocationEnabled
    }
    val notif = remember(tick) {
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }
    val vpn = remember(tick) { VpnService.prepare(ctx) == null }
    fun yn(b: Boolean) = if (b) "✅" else "❌"

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("الحالة والأذونات", style = MaterialTheme.typography.headlineMedium) }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("المراقبة تعمل: ${yn(Store.running)}")
                    Text("إذن الموقع: ${yn(loc)}")
                    Text("خدمة الموقع (GPS) مفعّلة: ${yn(locOn)}")
                    Text("إذن الإشعارات: ${yn(notif)}")
                    Text("صلاحية VPN للحظر: ${yn(vpn)}")
                    Text("الشبكة الحالية: ${Store.currentSsid.ifEmpty { "—" }}")
                    Text("آخر قراءة: ${fmt(Store.lastDelta)}")
                    Text("آخر كتابة للبيانات: ${fmtTime(Store.lastWrite)}")
                    Text("الحظر نشط الآن: ${yn(Store.blocking)}")
                }
            }
        }
        item {
            Button(modifier = Modifier.fillMaxWidth(), onClick = {
                val p = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
                permLauncher.launch(p.toTypedArray())
            }) { Text("1) منح أذونات الموقع والإشعارات") }
        }
        item {
            Button(modifier = Modifier.fillMaxWidth(), onClick = {
                val i = VpnService.prepare(ctx)
                if (i != null) vpnLauncher.launch(i) else Toast.makeText(ctx, "صلاحية VPN ممنوحة", Toast.LENGTH_SHORT).show()
            }) { Text("2) السماح بصلاحية VPN (للحظر)") }
        }
        item {
            Button(modifier = Modifier.fillMaxWidth(), onClick = {
                if (!loc) Toast.makeText(ctx, "امنح إذن الموقع أولاً", Toast.LENGTH_LONG).show()
                else ContextCompat.startForegroundService(ctx, Intent(ctx, TrackerService::class.java))
            }) { Text("3) تشغيل المراقبة") }
        }
        item {
            OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = {
                ctx.stopService(Intent(ctx, TrackerService::class.java))
                ctx.stopService(Intent(ctx, FirewallVpnService::class.java))
            }) { Text("إيقاف المراقبة والحظر") }
        }
        item {
            OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = {
                ctx.startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }) { Text("استثناء التطبيق من توفير البطارية") }
        }
        item {
            Text(
                "ملاحظة: الحظر عبر VPN يسري على كل الشبكات بما فيها بيانات الجوال طالما هو نشط، " +
                    "ويتوقف تلقائياً عند مغادرة الشبكة التي بلغت حدها.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

package com.wifipulse.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class TrackerService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private var last = -1L
    private var prevSsid: String? = null

    companion object { const val ACTION_UNBLOCK = "com.wifipulse.app.UNBLOCK" }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Store.init(this)
        createChannels()
        try {
            val n = NotificationCompat.Builder(this, "track")
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("مراقبة الواي فاي تعمل")
                .setOngoing(true).build()
            val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0
            ServiceCompat.startForeground(this, 1, n, type)
        } catch (e: Exception) { stopSelf(); return START_NOT_STICKY }
        Store.running = true

        if (intent?.action == ACTION_UNBLOCK) {
            WifiUtil.currentWifi(this)?.let { Store.setSnooze(it) }
            stopService(Intent(this, FirewallVpnService::class.java))
            Store.blocking = false
            nm().cancel(2)
        }
        if (job == null) job = scope.launch {
            while (isActive) { try { tick() } catch (_: Exception) {}; delay(15_000) }
        }
        return START_STICKY
    }

    private fun tick() {
        val ssid = WifiUtil.currentWifi(this)
        val now = WifiUtil.wifiBytes()
        if (last >= 0) {
            var d = now - last
            if (d < 0) d = now
            val target = prevSsid
            if (d > 0 && target != null) Store.add(target, d)
            Store.lastDelta = d
        }
        last = now
        prevSsid = ssid
        Store.currentSsid = ssid ?: ""
        if (ssid != null) Store.touch(ssid)
        evaluateBlock(ssid)
    }

    private fun overCap(ssid: String): Boolean {
        val mb = 1024L * 1024L
        val cd = Store.capDay(ssid); val cm = Store.capMonth(ssid)
        val day = Store.dayKey()
        if (cd > 0 && Store.usage(ssid, day) >= cd * mb) return true
        if (cm > 0 && Store.usage(ssid, day.substring(0, 6)) >= cm * mb) return true
        return false
    }

    private fun evaluateBlock(ssid: String?) {
        val should = ssid != null && Store.blockOn(ssid) && !Store.snoozed(ssid) && overCap(ssid)
        if (should) {
            if (!Store.blocking) {
                if (VpnService.prepare(this) == null) {
                    startService(Intent(this, FirewallVpnService::class.java))
                    notifyBlocked(ssid!!, true)
                } else notifyBlocked(ssid!!, false)
            }
        } else if (Store.blocking) {
            stopService(Intent(this, FirewallVpnService::class.java))
            Store.blocking = false
            nm().cancel(2)
        }
    }

    private fun notifyBlocked(ssid: String, active: Boolean) {
        val pi = PendingIntent.getService(
            this, 0, Intent(this, TrackerService::class.java).setAction(ACTION_UNBLOCK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val text = if (active) "تم حظر التطبيقات لأن الشبكة $ssid بلغت الحد"
        else "الشبكة $ssid بلغت الحد، لكن صلاحية VPN غير ممنوحة. افتح التطبيق ← الحالة"
        val n = NotificationCompat.Builder(this, "alert")
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle("بلغت حد البيانات")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .addAction(0, "إلغاء الحظر اليوم", pi)
            .setOngoing(active).build()
        nm().notify(2, n)
    }

    private fun nm() = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= 26) {
            nm().createNotificationChannel(NotificationChannel("track", "المراقبة", NotificationManager.IMPORTANCE_LOW))
            nm().createNotificationChannel(NotificationChannel("alert", "التنبيهات", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    override fun onDestroy() {
        Store.running = false
        scope.cancel()
        super.onDestroy()
    }
}
